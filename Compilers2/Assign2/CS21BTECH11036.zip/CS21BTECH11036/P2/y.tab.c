/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 1 "yacc.y"

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
extern FILE *yyin, *yytok, *tpar;
extern int yylineno;
int yylex();
void yyerror();

#line 81 "y.tab.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

/* Use api.header.include to #include this header
   instead of duplicating it here.  */
#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    INTEGER_CONSTANT = 258,        /* INTEGER_CONSTANT  */
    CHAR_CONSTANT = 259,           /* CHAR_CONSTANT  */
    STRING_CONSTANT = 260,         /* STRING_CONSTANT  */
    ID = 261,                      /* ID  */
    INT = 262,                     /* INT  */
    CHAR = 263,                    /* CHAR  */
    STRING = 264,                  /* STRING  */
    VOID = 265,                    /* VOID  */
    BOOL = 266,                    /* BOOL  */
    SEMICOLON = 267,               /* SEMICOLON  */
    COMMA = 268,                   /* COMMA  */
    COLON = 269,                   /* COLON  */
    SQLEFT = 270,                  /* SQLEFT  */
    SQRIGHT = 271,                 /* SQRIGHT  */
    BRLEFT = 272,                  /* BRLEFT  */
    BRRIGHT = 273,                 /* BRRIGHT  */
    PLEFT = 274,                   /* PLEFT  */
    PRIGHT = 275,                  /* PRIGHT  */
    DECLARE = 276,                 /* DECLARE  */
    CALL = 277,                    /* CALL  */
    RETURN = 278,                  /* RETURN  */
    CLASS = 279,                   /* CLASS  */
    THIS = 280,                    /* THIS  */
    GLOBAL = 281,                  /* GLOBAL  */
    LOCAL = 282,                   /* LOCAL  */
    IF = 283,                      /* IF  */
    DO = 284,                      /* DO  */
    ELSE = 285,                    /* ELSE  */
    FOR = 286,                     /* FOR  */
    WHILE = 287,                   /* WHILE  */
    LOOP = 288,                    /* LOOP  */
    EXPR = 289,                    /* EXPR  */
    TRUE = 290,                    /* TRUE  */
    FALSE = 291,                   /* FALSE  */
    AND = 292,                     /* AND  */
    OR = 293,                      /* OR  */
    NEG = 294,                     /* NEG  */
    LT = 295,                      /* LT  */
    GT = 296,                      /* GT  */
    GEQ = 297,                     /* GEQ  */
    LEQ = 298,                     /* LEQ  */
    NE = 299,                      /* NE  */
    EQ = 300,                      /* EQ  */
    ADD = 301,                     /* ADD  */
    SUB = 302,                     /* SUB  */
    MUL = 303,                     /* MUL  */
    DIV = 304,                     /* DIV  */
    POSTINCR = 305,                /* POSTINCR  */
    POSTDECR = 306,                /* POSTDECR  */
    ASSIGN = 307,                  /* ASSIGN  */
    ARROW = 308,                   /* ARROW  */
    INT_CONST_GTONE = 309          /* INT_CONST_GTONE  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif
/* Token kinds.  */
#define YYEMPTY -2
#define YYEOF 0
#define YYerror 256
#define YYUNDEF 257
#define INTEGER_CONSTANT 258
#define CHAR_CONSTANT 259
#define STRING_CONSTANT 260
#define ID 261
#define INT 262
#define CHAR 263
#define STRING 264
#define VOID 265
#define BOOL 266
#define SEMICOLON 267
#define COMMA 268
#define COLON 269
#define SQLEFT 270
#define SQRIGHT 271
#define BRLEFT 272
#define BRRIGHT 273
#define PLEFT 274
#define PRIGHT 275
#define DECLARE 276
#define CALL 277
#define RETURN 278
#define CLASS 279
#define THIS 280
#define GLOBAL 281
#define LOCAL 282
#define IF 283
#define DO 284
#define ELSE 285
#define FOR 286
#define WHILE 287
#define LOOP 288
#define EXPR 289
#define TRUE 290
#define FALSE 291
#define AND 292
#define OR 293
#define NEG 294
#define LT 295
#define GT 296
#define GEQ 297
#define LEQ 298
#define NE 299
#define EQ 300
#define ADD 301
#define SUB 302
#define MUL 303
#define DIV 304
#define POSTINCR 305
#define POSTDECR 306
#define ASSIGN 307
#define ARROW 308
#define INT_CONST_GTONE 309

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 11 "yacc.y"

    int val;
    char* sval;

#line 247 "y.tab.c"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;


int yyparse (void);


#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_INTEGER_CONSTANT = 3,           /* INTEGER_CONSTANT  */
  YYSYMBOL_CHAR_CONSTANT = 4,              /* CHAR_CONSTANT  */
  YYSYMBOL_STRING_CONSTANT = 5,            /* STRING_CONSTANT  */
  YYSYMBOL_ID = 6,                         /* ID  */
  YYSYMBOL_INT = 7,                        /* INT  */
  YYSYMBOL_CHAR = 8,                       /* CHAR  */
  YYSYMBOL_STRING = 9,                     /* STRING  */
  YYSYMBOL_VOID = 10,                      /* VOID  */
  YYSYMBOL_BOOL = 11,                      /* BOOL  */
  YYSYMBOL_SEMICOLON = 12,                 /* SEMICOLON  */
  YYSYMBOL_COMMA = 13,                     /* COMMA  */
  YYSYMBOL_COLON = 14,                     /* COLON  */
  YYSYMBOL_SQLEFT = 15,                    /* SQLEFT  */
  YYSYMBOL_SQRIGHT = 16,                   /* SQRIGHT  */
  YYSYMBOL_BRLEFT = 17,                    /* BRLEFT  */
  YYSYMBOL_BRRIGHT = 18,                   /* BRRIGHT  */
  YYSYMBOL_PLEFT = 19,                     /* PLEFT  */
  YYSYMBOL_PRIGHT = 20,                    /* PRIGHT  */
  YYSYMBOL_DECLARE = 21,                   /* DECLARE  */
  YYSYMBOL_CALL = 22,                      /* CALL  */
  YYSYMBOL_RETURN = 23,                    /* RETURN  */
  YYSYMBOL_CLASS = 24,                     /* CLASS  */
  YYSYMBOL_THIS = 25,                      /* THIS  */
  YYSYMBOL_GLOBAL = 26,                    /* GLOBAL  */
  YYSYMBOL_LOCAL = 27,                     /* LOCAL  */
  YYSYMBOL_IF = 28,                        /* IF  */
  YYSYMBOL_DO = 29,                        /* DO  */
  YYSYMBOL_ELSE = 30,                      /* ELSE  */
  YYSYMBOL_FOR = 31,                       /* FOR  */
  YYSYMBOL_WHILE = 32,                     /* WHILE  */
  YYSYMBOL_LOOP = 33,                      /* LOOP  */
  YYSYMBOL_EXPR = 34,                      /* EXPR  */
  YYSYMBOL_TRUE = 35,                      /* TRUE  */
  YYSYMBOL_FALSE = 36,                     /* FALSE  */
  YYSYMBOL_AND = 37,                       /* AND  */
  YYSYMBOL_OR = 38,                        /* OR  */
  YYSYMBOL_NEG = 39,                       /* NEG  */
  YYSYMBOL_LT = 40,                        /* LT  */
  YYSYMBOL_GT = 41,                        /* GT  */
  YYSYMBOL_GEQ = 42,                       /* GEQ  */
  YYSYMBOL_LEQ = 43,                       /* LEQ  */
  YYSYMBOL_NE = 44,                        /* NE  */
  YYSYMBOL_EQ = 45,                        /* EQ  */
  YYSYMBOL_ADD = 46,                       /* ADD  */
  YYSYMBOL_SUB = 47,                       /* SUB  */
  YYSYMBOL_MUL = 48,                       /* MUL  */
  YYSYMBOL_DIV = 49,                       /* DIV  */
  YYSYMBOL_POSTINCR = 50,                  /* POSTINCR  */
  YYSYMBOL_POSTDECR = 51,                  /* POSTDECR  */
  YYSYMBOL_ASSIGN = 52,                    /* ASSIGN  */
  YYSYMBOL_ARROW = 53,                     /* ARROW  */
  YYSYMBOL_INT_CONST_GTONE = 54,           /* INT_CONST_GTONE  */
  YYSYMBOL_YYACCEPT = 55,                  /* $accept  */
  YYSYMBOL_program = 56,                   /* program  */
  YYSYMBOL_method_ = 57,                   /* method_  */
  YYSYMBOL_58_1 = 58,                      /* $@1  */
  YYSYMBOL_59_2 = 59,                      /* $@2  */
  YYSYMBOL_method_body = 60,               /* method_body  */
  YYSYMBOL_class_ = 61,                    /* class_  */
  YYSYMBOL_62_3 = 62,                      /* $@3  */
  YYSYMBOL_63_4 = 63,                      /* $@4  */
  YYSYMBOL_class_body = 64,                /* class_body  */
  YYSYMBOL_statement_class = 65,           /* statement_class  */
  YYSYMBOL_statement = 66,                 /* statement  */
  YYSYMBOL_declaration_statement = 67,     /* declaration_statement  */
  YYSYMBOL_expression_statement = 68,      /* expression_statement  */
  YYSYMBOL_for_expr_statement = 69,        /* for_expr_statement  */
  YYSYMBOL_call_statement = 70,            /* call_statement  */
  YYSYMBOL_return_call = 71,               /* return_call  */
  YYSYMBOL_conditional_statement = 72,     /* conditional_statement  */
  YYSYMBOL_73_5 = 73,                      /* $@5  */
  YYSYMBOL_conditional_body = 74,          /* conditional_body  */
  YYSYMBOL_75_6 = 75,                      /* $@6  */
  YYSYMBOL_76_7 = 76,                      /* $@7  */
  YYSYMBOL_else_body = 77,                 /* else_body  */
  YYSYMBOL_loop_statement = 78,            /* loop_statement  */
  YYSYMBOL_79_8 = 79,                      /* $@8  */
  YYSYMBOL_80_9 = 80,                      /* $@9  */
  YYSYMBOL_81_10 = 81,                     /* $@10  */
  YYSYMBOL_for_body = 82,                  /* for_body  */
  YYSYMBOL_while_body = 83,                /* while_body  */
  YYSYMBOL_stat_return_statement = 84,     /* stat_return_statement  */
  YYSYMBOL_return_statement = 85,          /* return_statement  */
  YYSYMBOL_rhs_expression = 86,            /* rhs_expression  */
  YYSYMBOL_predicate = 87,                 /* predicate  */
  YYSYMBOL_sup_predicate = 88,             /* sup_predicate  */
  YYSYMBOL_extra = 89,                     /* extra  */
  YYSYMBOL_extra_neg = 90,                 /* extra_neg  */
  YYSYMBOL_pre_operator = 91,              /* pre_operator  */
  YYSYMBOL_pred_operator = 92,             /* pred_operator  */
  YYSYMBOL_un_expression = 93,             /* un_expression  */
  YYSYMBOL_un_statement = 94,              /* un_statement  */
  YYSYMBOL_unn_statement = 95,             /* unn_statement  */
  YYSYMBOL_bin_operator = 96,              /* bin_operator  */
  YYSYMBOL_un_operator = 97,               /* un_operator  */
  YYSYMBOL_scope_specifier = 98,           /* scope_specifier  */
  YYSYMBOL_type_specifier = 99,            /* type_specifier  */
  YYSYMBOL_constant = 100,                 /* constant  */
  YYSYMBOL_id_list = 101,                  /* id_list  */
  YYSYMBOL_count = 102,                    /* count  */
  YYSYMBOL_func_arg = 103,                 /* func_arg  */
  YYSYMBOL_arg = 104                       /* arg  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_int16 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  9
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   398

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  55
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  50
/* YYNRULES -- Number of rules.  */
#define YYNRULES  127
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  293

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   309


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   101,   101,   102,   103,   107,   107,   108,   108,   112,
     116,   116,   117,   117,   121,   125,   126,   128,   133,   134,
     135,   136,   137,   138,   140,   147,   148,   152,   156,   160,
     161,   162,   163,   164,   165,   169,   170,   171,   172,   173,
     174,   178,   178,   182,   182,   183,   183,   184,   185,   189,
     190,   193,   193,   194,   194,   195,   195,   199,   200,   204,
     205,   209,   213,   214,   215,   216,   217,   218,   222,   223,
     224,   225,   226,   227,   228,   229,   233,   234,   237,   238,
     239,   240,   241,   245,   246,   250,   251,   255,   256,   260,
     261,   262,   263,   264,   265,   266,   267,   271,   272,   273,
     277,   281,   286,   287,   288,   289,   293,   294,   298,   299,
     303,   304,   305,   306,   307,   311,   312,   313,   314,   318,
     319,   323,   327,   328,   332,   333,   334,   335
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "INTEGER_CONSTANT",
  "CHAR_CONSTANT", "STRING_CONSTANT", "ID", "INT", "CHAR", "STRING",
  "VOID", "BOOL", "SEMICOLON", "COMMA", "COLON", "SQLEFT", "SQRIGHT",
  "BRLEFT", "BRRIGHT", "PLEFT", "PRIGHT", "DECLARE", "CALL", "RETURN",
  "CLASS", "THIS", "GLOBAL", "LOCAL", "IF", "DO", "ELSE", "FOR", "WHILE",
  "LOOP", "EXPR", "TRUE", "FALSE", "AND", "OR", "NEG", "LT", "GT", "GEQ",
  "LEQ", "NE", "EQ", "ADD", "SUB", "MUL", "DIV", "POSTINCR", "POSTDECR",
  "ASSIGN", "ARROW", "INT_CONST_GTONE", "$accept", "program", "method_",
  "$@1", "$@2", "method_body", "class_", "$@3", "$@4", "class_body",
  "statement_class", "statement", "declaration_statement",
  "expression_statement", "for_expr_statement", "call_statement",
  "return_call", "conditional_statement", "$@5", "conditional_body", "$@6",
  "$@7", "else_body", "loop_statement", "$@8", "$@9", "$@10", "for_body",
  "while_body", "stat_return_statement", "return_statement",
  "rhs_expression", "predicate", "sup_predicate", "extra", "extra_neg",
  "pre_operator", "pred_operator", "un_expression", "un_statement",
  "unn_statement", "bin_operator", "un_operator", "scope_specifier",
  "type_specifier", "constant", "id_list", "count", "func_arg", "arg", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-221)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-83)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
      90,     8,  -221,  -221,    23,    90,    90,   246,    11,  -221,
    -221,  -221,  -221,  -221,  -221,  -221,  -221,    35,    -3,    59,
     125,  -221,    63,   110,  -221,    -3,   102,  -221,   239,   110,
     115,   110,   114,  -221,    59,   153,   153,  -221,  -221,  -221,
     143,   161,  -221,  -221,   163,   193,   246,   201,  -221,  -221,
     194,  -221,   208,   105,    15,   211,   214,   154,   232,  -221,
    -221,   197,   201,   201,   201,   201,   201,   244,   251,   201,
     245,  -221,  -221,   246,  -221,    19,   212,    13,   233,   247,
     216,   167,   201,  -221,  -221,  -221,  -221,  -221,  -221,  -221,
    -221,    78,   263,   161,    -3,   250,   265,   266,  -221,  -221,
    -221,    86,    99,    25,  -221,  -221,   107,  -221,  -221,  -221,
    -221,  -221,  -221,   199,   253,  -221,    87,  -221,    88,   255,
      89,   269,    13,    13,   162,   264,   267,  -221,   268,   270,
     271,  -221,  -221,   257,  -221,  -221,  -221,  -221,   262,   272,
     137,   180,   261,    24,   234,  -221,   249,  -221,  -221,  -221,
    -221,  -221,  -221,  -221,  -221,  -221,   162,  -221,   162,   237,
     273,   274,  -221,   278,  -221,  -221,  -221,  -221,  -221,  -221,
    -221,  -221,  -221,   276,  -221,    -3,   277,    -3,   279,   221,
      -3,   280,   285,   286,    65,   281,  -221,   275,   283,   162,
      45,  -221,  -221,   177,   282,   290,   287,   293,  -221,  -221,
     288,   292,  -221,   188,   200,  -221,   289,  -221,   162,   297,
    -221,   291,   284,   299,   301,   295,   298,  -221,   300,  -221,
      99,   302,    -3,   296,    -3,   303,   201,   304,  -221,   305,
    -221,   308,  -221,   177,   177,   306,   177,   177,   307,   177,
     294,  -221,   310,  -221,     6,   311,  -221,   201,  -221,   305,
     201,  -221,  -221,  -221,   312,   313,  -221,   314,   309,   316,
     256,   315,   140,   318,  -221,   151,   319,   326,   327,  -221,
     177,   177,  -221,  -221,  -221,  -221,  -221,  -221,  -221,  -221,
     320,   321,   325,   325,  -221,  -221,   201,  -221,  -221,   169,
     328,  -221,  -221
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_int8 yydefact[] =
{
       4,     0,   108,   109,     0,     4,     4,     0,    12,     1,
       2,     3,   110,   111,   112,   114,   113,     0,     0,     0,
       0,   121,     0,    17,    13,     0,     0,    10,     0,    17,
       0,    17,     0,     7,     0,     0,     0,    16,    14,    15,
       0,     0,    11,   119,     0,     0,     0,    24,     8,    26,
       0,    25,     0,     0,     0,     0,     0,     0,     0,   106,
     107,     0,    24,    24,    24,    24,    24,     0,     0,    24,
       0,   120,   122,     0,     5,     0,     0,     0,     0,     0,
       0,     0,    24,    18,    19,    20,    21,    22,     9,   101,
      23,     0,     0,     0,     0,     0,     0,     0,   115,   116,
     117,    68,     0,     0,    74,    75,     0,   102,   103,   104,
     105,   118,    72,     0,     0,    76,    73,    83,    71,     0,
      69,     0,     0,     0,     0,     0,     0,    62,     0,     0,
       0,    61,    97,     0,    99,    98,   123,     6,     0,     0,
       0,     0,     0,     0,     0,    85,     0,    86,    95,    96,
      89,    90,    91,    92,    93,    94,     0,    41,     0,     0,
       0,     0,    68,     0,    73,    71,    69,    64,    63,    66,
      65,    67,   100,     0,    34,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    78,     0,     0,     0,
       0,    51,    27,     0,     0,     0,     0,     0,    87,    88,
       0,     0,    40,     0,     0,    84,     0,    42,     0,     0,
      55,     0,     0,   125,   124,     0,     0,    31,     0,    32,
       0,     0,     0,     0,     0,     0,    24,     0,    28,     0,
      53,     0,    52,     0,     0,     0,     0,     0,     0,     0,
       0,    37,     0,    38,     0,     0,    70,    24,    56,     0,
      24,   127,   126,    33,     0,     0,    77,     0,     0,     0,
      47,    48,     0,     0,    54,     0,     0,     0,     0,    39,
       0,     0,    43,    45,    57,    58,    60,    59,    29,    30,
       0,     0,     0,     0,    35,    36,    24,    44,    46,     0,
       0,    49,    50
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -221,   220,    57,  -221,  -221,   227,  -221,  -221,  -221,   259,
     112,   -62,    62,  -221,  -221,  -221,   317,  -221,  -221,  -221,
    -221,  -221,    47,  -221,  -221,  -221,  -221,    82,  -221,  -220,
    -221,  -114,   138,   -93,  -111,   198,  -221,  -221,  -221,   -66,
    -221,  -221,  -221,  -221,     0,   -69,   322,   -20,  -221,   -43
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
       0,     4,     5,    93,    41,    48,     6,    34,    19,    24,
      30,    61,    62,    63,   122,    64,   112,    65,   187,   207,
     282,   283,   287,    66,   212,   249,   229,   248,   232,    67,
      82,   113,   114,   115,   116,   117,   200,   156,   133,    68,
      69,   119,    70,     7,    17,   214,    44,    22,    53,   215
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      83,    84,    85,    86,    87,    32,   245,    90,   120,   142,
     163,   118,   130,   164,     8,   129,    98,    99,   100,   101,
     131,    75,   135,     9,   260,   134,    18,   263,    36,    81,
     266,   143,   102,   120,    94,   103,   118,   147,    95,   180,
      76,    20,   186,   181,   188,   164,    52,   164,   104,   105,
     144,    21,   106,   120,   120,   166,   118,   118,   165,   107,
     108,   109,   110,    59,    60,   210,   290,   111,    98,    99,
     100,   145,    96,    92,   138,   209,    23,   182,   164,    27,
      29,    98,    99,   100,   132,    31,    29,   166,    29,   166,
     165,    31,   165,    31,   227,    59,    60,   164,   -80,   -82,
     -79,   -81,    98,    99,   100,   101,   -80,   -82,   -79,   -81,
      98,    99,   100,   145,     1,   147,     2,     3,    73,   111,
     166,   103,    33,   165,   211,    74,   146,   238,    59,    60,
      40,    28,   111,    38,   104,   105,     2,     3,   106,   166,
      25,    37,   165,    39,    26,   107,   108,   109,   110,    59,
      60,   120,   175,   111,   118,   194,   176,   196,   274,    43,
     201,   111,    46,    81,   244,    98,    99,   100,   162,   276,
      98,    99,   100,   125,    81,    49,    50,   126,    47,   127,
      98,    99,   100,   213,   103,   262,    79,   291,   265,   103,
     251,   252,    81,   254,   255,   177,   257,   104,   105,   178,
      71,   106,   240,   222,   242,    51,    50,   223,   107,   108,
     109,   110,    59,    60,    72,   224,   111,    59,    60,   225,
      81,   111,    28,    54,   289,    10,    11,   280,   281,    55,
      77,   111,    56,    78,    57,    58,   148,   149,    80,   150,
     151,   152,   153,   154,   155,    35,    12,    13,    14,    15,
      16,    59,    60,    12,    13,    14,    15,    16,   198,   199,
     160,   161,    88,    89,    91,    97,   123,   121,   124,   136,
     139,   140,   141,   157,   158,   159,   167,   172,   173,   168,
     169,   179,   170,   171,   174,   190,   272,   183,   184,   189,
     192,   203,   204,    42,   191,   193,   208,   195,   216,   197,
     202,   205,   217,   218,   206,   219,   226,   220,   221,   228,
     258,   230,   233,   231,   234,   235,   241,   236,   253,   237,
     137,   239,   247,   243,   246,   250,   259,   256,   270,   261,
     288,   264,   267,   268,   269,   271,   275,   277,   278,   279,
     284,   285,   286,     0,   185,   273,   292,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    45,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   128
};

static const yytype_int16 yycheck[] =
{
      62,    63,    64,    65,    66,    25,   226,    69,    77,   102,
     124,    77,    81,   124,     6,    81,     3,     4,     5,     6,
      82,     6,    91,     0,    18,    91,    15,   247,    28,    23,
     250,     6,    19,   102,    15,    22,   102,   106,    19,    15,
      25,     6,   156,    19,   158,   156,    46,   158,    35,    36,
      25,    54,    39,   122,   123,   124,   122,   123,   124,    46,
      47,    48,    49,    50,    51,    20,   286,    54,     3,     4,
       5,     6,    53,    73,    94,   189,    17,    53,   189,    16,
      23,     3,     4,     5,     6,    23,    29,   156,    31,   158,
     156,    29,   158,    31,   208,    50,    51,   208,    12,    12,
      12,    12,     3,     4,     5,     6,    20,    20,    20,    20,
       3,     4,     5,     6,    24,   184,    26,    27,    13,    54,
     189,    22,    20,   189,   190,    20,    19,   220,    50,    51,
      16,    21,    54,    18,    35,    36,    26,    27,    39,   208,
      15,    29,   208,    31,    19,    46,    47,    48,    49,    50,
      51,   220,    15,    54,   220,   175,    19,   177,    18,     6,
     180,    54,    19,    23,   226,     3,     4,     5,     6,    18,
       3,     4,     5,     6,    23,    12,    13,    10,    17,    12,
       3,     4,     5,     6,    22,   247,    32,    18,   250,    22,
     233,   234,    23,   236,   237,    15,   239,    35,    36,    19,
       6,    39,   222,    15,   224,    12,    13,    19,    46,    47,
      48,    49,    50,    51,     6,    15,    54,    50,    51,    19,
      23,    54,    21,    22,   286,     5,     6,   270,   271,    28,
      19,    54,    31,    19,    33,    34,    37,    38,     6,    40,
      41,    42,    43,    44,    45,     6,     7,     8,     9,    10,
      11,    50,    51,     7,     8,     9,    10,    11,    37,    38,
     122,   123,    18,    12,    19,    53,    19,    34,    52,     6,
      20,     6,     6,    20,    19,     6,    12,    20,    16,    12,
      12,    20,    12,    12,    12,    12,    30,    53,    39,    52,
      12,     6,     6,    34,    20,    19,    13,    20,    16,    20,
      20,    20,    12,    16,    29,    12,    17,    19,    16,    12,
      16,    20,    13,    29,    13,    20,    20,    19,    12,    19,
      93,    19,    17,    20,    20,    17,    16,    20,    19,    18,
     283,   249,    20,    20,    20,    19,    18,    18,    12,    12,
      20,    20,    17,    -1,   146,    30,    18,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    36,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    81
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int8 yystos[] =
{
       0,    24,    26,    27,    56,    57,    61,    98,     6,     0,
      56,    56,     7,     8,     9,    10,    11,    99,    15,    63,
       6,    54,   102,    17,    64,    15,    19,    16,    21,    57,
      65,    67,   102,    20,    62,     6,    99,    65,    18,    65,
      16,    59,    64,     6,   101,   101,    19,    17,    60,    12,
      13,    12,    99,   103,    22,    28,    31,    33,    34,    50,
      51,    66,    67,    68,    70,    72,    78,    84,    94,    95,
      97,     6,     6,    13,    20,     6,    25,    19,    19,    32,
       6,    23,    85,    66,    66,    66,    66,    66,    18,    12,
      66,    19,    99,    58,    15,    19,    53,    53,     3,     4,
       5,     6,    19,    22,    35,    36,    39,    46,    47,    48,
      49,    54,    71,    86,    87,    88,    89,    90,    94,    96,
     100,    34,    69,    19,    52,     6,    10,    12,    71,    94,
     100,    66,     6,    93,    94,   100,     6,    60,   102,    20,
       6,     6,    88,     6,    25,     6,    19,   100,    37,    38,
      40,    41,    42,    43,    44,    45,    92,    20,    19,     6,
      87,    87,     6,    86,    89,    94,   100,    12,    12,    12,
      12,    12,    20,    16,    12,    15,    19,    15,    19,    20,
      15,    19,    53,    53,    39,    90,    86,    73,    86,    52,
      12,    20,    12,    19,   102,    20,   102,    20,    37,    38,
      91,   102,    20,     6,     6,    20,    29,    74,    13,    86,
      20,    94,    79,     6,   100,   104,    16,    12,    16,    12,
      19,    16,    15,    19,    15,    19,    17,    86,    12,    81,
      20,    29,    83,    13,    13,    20,    19,    19,    88,    19,
     102,    20,   102,    20,    66,    84,    20,    17,    82,    80,
      17,   104,   104,    12,   104,   104,    20,   104,    16,    16,
      18,    18,    66,    84,    82,    66,    84,    20,    20,    20,
      19,    19,    30,    30,    18,    18,    18,    18,    12,    12,
     104,   104,    75,    76,    20,    20,    17,    77,    77,    66,
      84,    18,    18
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr1[] =
{
       0,    55,    56,    56,    56,    58,    57,    59,    57,    60,
      62,    61,    63,    61,    64,    65,    65,    65,    66,    66,
      66,    66,    66,    66,    66,    67,    67,    68,    69,    70,
      70,    70,    70,    70,    70,    71,    71,    71,    71,    71,
      71,    73,    72,    75,    74,    76,    74,    74,    74,    77,
      77,    79,    78,    80,    78,    81,    78,    82,    82,    83,
      83,    84,    85,    85,    85,    85,    85,    85,    86,    86,
      86,    86,    86,    86,    86,    86,    87,    87,    88,    88,
      88,    88,    88,    89,    89,    90,    90,    91,    91,    92,
      92,    92,    92,    92,    92,    92,    92,    93,    93,    93,
      94,    95,    96,    96,    96,    96,    97,    97,    98,    98,
      99,    99,    99,    99,    99,   100,   100,   100,   100,   101,
     101,   102,   103,   103,   104,   104,   104,   104
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     2,     2,     0,     0,    11,     0,     7,     3,
       0,     7,     0,     4,     3,     2,     2,     0,     2,     2,
       2,     2,     2,     2,     0,     4,     4,     5,     5,    11,
      11,     7,     7,     9,     5,    10,    10,     6,     6,     8,
       4,     0,     6,     0,     7,     0,     7,     4,     4,     3,
       3,     0,     7,     0,     9,     0,     8,     3,     3,     4,
       4,     3,     2,     3,     3,     3,     3,     3,     1,     1,
       6,     1,     1,     1,     1,     1,     1,     7,     3,     1,
       1,     1,     1,     1,     4,     2,     2,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       4,     2,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       3,     1,     2,     4,     1,     1,     3,     3
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)




# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  yy_symbol_value_print (yyo, yykind, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)]);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep)
{
  YY_USE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 5: /* $@1: %empty  */
#line 107 "yacc.y"
                                                                                   {fprintf(tpar, " : function definition");}
#line 1546 "y.tab.c"
    break;

  case 7: /* $@2: %empty  */
#line 108 "yacc.y"
                                                     {fprintf(tpar, " : function definition");}
#line 1552 "y.tab.c"
    break;

  case 10: /* $@3: %empty  */
#line 116 "yacc.y"
                                    {fprintf(tpar, " : class definition");}
#line 1558 "y.tab.c"
    break;

  case 12: /* $@4: %empty  */
#line 117 "yacc.y"
               {fprintf(tpar, " : class definition ");}
#line 1564 "y.tab.c"
    break;

  case 17: /* statement_class: %empty  */
#line 128 "yacc.y"
    {
        //
    }
#line 1572 "y.tab.c"
    break;

  case 24: /* statement: %empty  */
#line 140 "yacc.y"
    {
        //
    }
#line 1580 "y.tab.c"
    break;

  case 25: /* declaration_statement: DECLARE type_specifier id_list SEMICOLON  */
#line 147 "yacc.y"
                                               {fprintf(tpar, " : declaration statement");}
#line 1586 "y.tab.c"
    break;

  case 26: /* declaration_statement: DECLARE ID id_list SEMICOLON  */
#line 148 "yacc.y"
                                   {fprintf(tpar, " : declaration statement");}
#line 1592 "y.tab.c"
    break;

  case 27: /* expression_statement: EXPR ID ASSIGN rhs_expression SEMICOLON  */
#line 152 "yacc.y"
                                              {fprintf(tpar," : expression statement");}
#line 1598 "y.tab.c"
    break;

  case 29: /* call_statement: CALL ID ARROW ID SQLEFT count SQRIGHT PLEFT arg PRIGHT SEMICOLON  */
#line 160 "yacc.y"
                                                                       { fprintf(tpar," : call statement with object");}
#line 1604 "y.tab.c"
    break;

  case 30: /* call_statement: CALL THIS ARROW ID SQLEFT count SQRIGHT PLEFT arg PRIGHT SEMICOLON  */
#line 161 "yacc.y"
                                                                         {fprintf(tpar, " : call statement with object");}
#line 1610 "y.tab.c"
    break;

  case 31: /* call_statement: CALL ID ARROW ID PLEFT PRIGHT SEMICOLON  */
#line 162 "yacc.y"
                                              {fprintf(tpar, " : call statement with object");}
#line 1616 "y.tab.c"
    break;

  case 32: /* call_statement: CALL THIS ARROW ID PLEFT PRIGHT SEMICOLON  */
#line 163 "yacc.y"
                                                {fprintf(tpar, " : call statement with object");}
#line 1622 "y.tab.c"
    break;

  case 33: /* call_statement: CALL ID SQLEFT count SQRIGHT PLEFT arg PRIGHT SEMICOLON  */
#line 164 "yacc.y"
                                                              {fprintf(tpar," : call statement with function");}
#line 1628 "y.tab.c"
    break;

  case 34: /* call_statement: CALL ID PLEFT PRIGHT SEMICOLON  */
#line 165 "yacc.y"
                                     {fprintf(tpar," : call statement with function");}
#line 1634 "y.tab.c"
    break;

  case 41: /* $@5: %empty  */
#line 178 "yacc.y"
                                    {fprintf(tpar," : conditional statement");}
#line 1640 "y.tab.c"
    break;

  case 43: /* $@6: %empty  */
#line 182 "yacc.y"
                                       {fprintf(tpar," : conditional statement");}
#line 1646 "y.tab.c"
    break;

  case 45: /* $@7: %empty  */
#line 183 "yacc.y"
                                                   {fprintf(tpar," : conditional statement");}
#line 1652 "y.tab.c"
    break;

  case 51: /* $@8: %empty  */
#line 193 "yacc.y"
                                        {fprintf(tpar," : loop");}
#line 1658 "y.tab.c"
    break;

  case 53: /* $@9: %empty  */
#line 194 "yacc.y"
                                                                           {fprintf(tpar," : loop");}
#line 1664 "y.tab.c"
    break;

  case 55: /* $@10: %empty  */
#line 195 "yacc.y"
                                                              {fprintf(tpar," : loop");}
#line 1670 "y.tab.c"
    break;

  case 62: /* return_statement: RETURN SEMICOLON  */
#line 213 "yacc.y"
                       {fprintf(tpar," : return statement");}
#line 1676 "y.tab.c"
    break;

  case 63: /* return_statement: RETURN VOID SEMICOLON  */
#line 214 "yacc.y"
                            {fprintf(tpar," : return statement");}
#line 1682 "y.tab.c"
    break;

  case 64: /* return_statement: RETURN ID SEMICOLON  */
#line 215 "yacc.y"
                          {fprintf(tpar," : return statement");}
#line 1688 "y.tab.c"
    break;

  case 65: /* return_statement: RETURN un_statement SEMICOLON  */
#line 216 "yacc.y"
                                    {fprintf(tpar," : return statement");}
#line 1694 "y.tab.c"
    break;

  case 66: /* return_statement: RETURN return_call SEMICOLON  */
#line 217 "yacc.y"
                                   {fprintf(tpar," : return statement");}
#line 1700 "y.tab.c"
    break;

  case 67: /* return_statement: RETURN constant SEMICOLON  */
#line 218 "yacc.y"
                                {fprintf(tpar," : return statement");}
#line 1706 "y.tab.c"
    break;

  case 101: /* unn_statement: un_statement SEMICOLON  */
#line 281 "yacc.y"
                             {fprintf(tpar," : call statement");}
#line 1712 "y.tab.c"
    break;


#line 1716 "y.tab.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (YY_("syntax error"));
    }

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

#line 339 "yacc.y"



void yyerror(char *msg){
    fprintf(tpar, " : invalid statement\n");
}

int main(void) {
    yyin = fopen("input.txt", "r");
    yytok = fopen("seq_tokens.txt", "w");
    tpar = fopen("parser.parsed", "w");

    fprintf(yytok,"Santoshi Gayatri Mavuru\n");
    fprintf(yytok,"CS21BTECH11036\n");

    yyparse();

    fclose(tpar);
    fclose(yyin);
    fclose(yytok);
    return 0;
}
