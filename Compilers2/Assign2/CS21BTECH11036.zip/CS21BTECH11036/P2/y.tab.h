/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    INTEGER_CONSTANT = 258,        /* INTEGER_CONSTANT  */
    CHAR_CONSTANT = 259,           /* CHAR_CONSTANT  */
    STRING_CONSTANT = 260,         /* STRING_CONSTANT  */
    ID = 261,                      /* ID  */
    INT = 262,                     /* INT  */
    CHAR = 263,                    /* CHAR  */
    STRING = 264,                  /* STRING  */
    VOID = 265,                    /* VOID  */
    BOOL = 266,                    /* BOOL  */
    SEMICOLON = 267,               /* SEMICOLON  */
    COMMA = 268,                   /* COMMA  */
    COLON = 269,                   /* COLON  */
    SQLEFT = 270,                  /* SQLEFT  */
    SQRIGHT = 271,                 /* SQRIGHT  */
    BRLEFT = 272,                  /* BRLEFT  */
    BRRIGHT = 273,                 /* BRRIGHT  */
    PLEFT = 274,                   /* PLEFT  */
    PRIGHT = 275,                  /* PRIGHT  */
    DECLARE = 276,                 /* DECLARE  */
    CALL = 277,                    /* CALL  */
    RETURN = 278,                  /* RETURN  */
    CLASS = 279,                   /* CLASS  */
    THIS = 280,                    /* THIS  */
    GLOBAL = 281,                  /* GLOBAL  */
    LOCAL = 282,                   /* LOCAL  */
    IF = 283,                      /* IF  */
    DO = 284,                      /* DO  */
    ELSE = 285,                    /* ELSE  */
    FOR = 286,                     /* FOR  */
    WHILE = 287,                   /* WHILE  */
    LOOP = 288,                    /* LOOP  */
    EXPR = 289,                    /* EXPR  */
    TRUE = 290,                    /* TRUE  */
    FALSE = 291,                   /* FALSE  */
    AND = 292,                     /* AND  */
    OR = 293,                      /* OR  */
    NEG = 294,                     /* NEG  */
    LT = 295,                      /* LT  */
    GT = 296,                      /* GT  */
    GEQ = 297,                     /* GEQ  */
    LEQ = 298,                     /* LEQ  */
    NE = 299,                      /* NE  */
    EQ = 300,                      /* EQ  */
    ADD = 301,                     /* ADD  */
    SUB = 302,                     /* SUB  */
    MUL = 303,                     /* MUL  */
    DIV = 304,                     /* DIV  */
    POSTINCR = 305,                /* POSTINCR  */
    POSTDECR = 306,                /* POSTDECR  */
    ASSIGN = 307,                  /* ASSIGN  */
    ARROW = 308,                   /* ARROW  */
    INT_CONST_GTONE = 309          /* INT_CONST_GTONE  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif
/* Token kinds.  */
#define YYEMPTY -2
#define YYEOF 0
#define YYerror 256
#define YYUNDEF 257
#define INTEGER_CONSTANT 258
#define CHAR_CONSTANT 259
#define STRING_CONSTANT 260
#define ID 261
#define INT 262
#define CHAR 263
#define STRING 264
#define VOID 265
#define BOOL 266
#define SEMICOLON 267
#define COMMA 268
#define COLON 269
#define SQLEFT 270
#define SQRIGHT 271
#define BRLEFT 272
#define BRRIGHT 273
#define PLEFT 274
#define PRIGHT 275
#define DECLARE 276
#define CALL 277
#define RETURN 278
#define CLASS 279
#define THIS 280
#define GLOBAL 281
#define LOCAL 282
#define IF 283
#define DO 284
#define ELSE 285
#define FOR 286
#define WHILE 287
#define LOOP 288
#define EXPR 289
#define TRUE 290
#define FALSE 291
#define AND 292
#define OR 293
#define NEG 294
#define LT 295
#define GT 296
#define GEQ 297
#define LEQ 298
#define NE 299
#define EQ 300
#define ADD 301
#define SUB 302
#define MUL 303
#define DIV 304
#define POSTINCR 305
#define POSTDECR 306
#define ASSIGN 307
#define ARROW 308
#define INT_CONST_GTONE 309

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 11 "yacc.y"

    int val;
    char* sval;

#line 180 "y.tab.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;


int yyparse (void);


#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
