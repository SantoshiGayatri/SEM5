import socket

server_ip = "10.0.1.3"
cache_ip = "10.0.1.2"

dport1 = 12345
dport2 = 12346

ser = socket.socket()
cac = socket.socket()
ser.connect((server_ip, dport1))
cac.bind((cache_ip, dport2))

print ("Sockets successfully created")
print ("socket 2 binded to %s" %(dport2))

cac.listen(5)
print ("socket 2  is listening")

cache_table = {}
flag = 0


while True:
  c, addr = cac.accept()
  print ('Got connection from', addr )
  while True:
    message = c.recv(1024).decode()
    if(len(message) == 0):
        flag = 1
        print('Cache received nothing')
        break
    
    print('Cache received '+ message)
    message_1 = message
    message_1 = message_1.replace("HTTP/1.1\n",'')
    
    if(message_1[0:3] == "PUT"):
        message_1 = message_1[17:]
        
        ind1 = message_1.find('/')

        key = message_1[0:ind1]
        val = message_1[ind1+1:-1]
        
        ser.send(message.encode())
	ser_msg = ser.recv(1024).decode()
	c.send(ser_msg.encode())
  
    elif(message_1[0:3] == "GET"):
        key = message_1[25:-1]
        if key in cache_table.keys():
            val = cache_table[key]
            c.send('HTTP/1.1 200 OK\nValue = '+ val.encode())
            print("Already in cache\n")
        else:
            ser.send(message.encode())
            ser_msg = ser.recv(1024).decode()

            if(ser_msg[9:12] == "200"):
                val = ser_msg[24:-2]
                cache_table[key] = val
		c.send(ser_msg.encode())

            else:
                c.send(ser_msg.encode())

    else:
        c.send('HTTP/1.1 400 bad request\n'.encode())
  if(flag == 1):
    break

c.close()

