import socket

server_ip = "10.0.1.3"

s = socket.socket()
print ("Socket successfully created")

dport = 12345

s.bind((server_ip, dport))
print ("socket binded to %s" %(dport))

s.listen(5)
print ("socket is listening")

server_table = {}
flag = 0


while True:
	c, addr = s.accept()
	print ('Got connection from ', addr )
	while True:
		message = c.recv(1024).decode()
		
		if(len(message) == 0):
			flag = 1
			print('Server received nothing')
			break

		print('Server received '+ message)
		message = message.replace("HTTP/1.1\n",'')

		if(message[0:3] == "PUT"):
			message = message[17:]
		
			ind1 = message.find('/')

			key = message[0:ind1]
			val = message[ind1+1:-1]
		
			server_table[key] = val
			c.send('HTTP/1.1 201 OK\r\n'.encode())

		elif(message[0:3] == "GET"):

			key = message[25:-1]
			if key in server_table.keys():
				val = server_table[key]
				c.send('HTTP/1.1 200 OK\nValue = '+ val +' \n'.encode())
			else:
				c.send('HTTP/1.1 404 not found\r\n'.encode())

		else:
			c.send('HTTP/1.1 400 bad request\r\n'.encode())
	if(flag == 1):
		break

c.close()

