import socket

server_ip = "10.0.1.2"
s = socket.socket()
port = 12346
s.connect((server_ip, port))

print('--------------------------- \nPUT - PUT request\nGET - GET request\nDELETE - DELETE request\nEXIT - to end the process\n')

while True:
    print('Enter the type of http request:')
    request = input()
    if request == 'EXIT':
        print('Exiting...')
        break
    elif request in ['PUT','GET', 'DELETE']:
        key = input('Enter the Key: ')
        if request == 'PUT':
            value = input('Enter the Value: ')
            s.send('PUT /assignment2/' +key+'/' +value+' HTTP/1.1\n'.encode())
        elif request == 'GET':
            s.send('GET /assignment2?request='+key+' HTTP/1.1\n'.encode())
        else:
            s.send('DELETE /assignment2/'+key+' HTTP/1.1\n'.encode())
        print('Client received ' + s.recv(1024).decode())
    else:
        print('Enter a valid type of request.')

s.close()
