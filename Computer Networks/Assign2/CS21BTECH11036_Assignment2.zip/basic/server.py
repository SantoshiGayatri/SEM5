import socket

server_ip = "10.0.1.2"

s = socket.socket()
print ("Socket successfully created")

dport = 12346

s.bind((server_ip, dport))
print ("socket binded to %s" %(dport))

s.listen(5)
print ("socket is listening")

my_table = {}
flag = 0

while True:
  c, addr = s.accept()
  print ('Got connection from ', addr )
  while True:
	recvmsg = c.recv(1024).decode()
    
	if(len(recvmsg) == 0):
         flag = 1
         print('Server received nothing')
    	 break;

	print('Server received '+ recvmsg)
	recvmsg = recvmsg.replace("HTTP/1.1\n",'')

	if(recvmsg[0:3] == "PUT"):
    	 recvmsg = recvmsg[17:]
   	 
    	 ind1 = recvmsg.find('/')

    	 key =recvmsg[0:ind1]
    	 val = recvmsg[ind1+1:-1]
   	 
    	 my_table[key] = val
    	 c.send('HTTP/1.1 201 OK\r\n'.encode())

	elif(recvmsg[0:3] == "GET"):

    	 key = recvmsg[25:-1]
    	 if key in my_table.keys():
        	val = my_table[key]
        	c.send('HTTP/1.1 200 OK\nValue = '+ val +'\n'.encode())
    	 else:
        	c.send('HTTP/1.1 404 not found\r\n'.encode())


	elif(recvmsg[0:6] == "DELETE"):

    	 key = recvmsg[20:-1]
    	 if key in my_table.keys():
        	del my_table[key]
        	c.send('HTTP/1.1 200 OK\nKey = '+ key +' deleted successfully\r\n'.encode())
    	 else:
        	c.send('HTTP/1.1 404 not found\r\n'.encode())

	else:
    	 c.send('HTTP/1.1 400 bad request\r\n'.encode())
  if(flag == 1):
    break

c.close()
