import socket

#WRITE CODE HERE:
#1. Create a KEY-VALUE pairs (Create a dictionary OR Maintain a text file for KEY-VALUES).


# dst_ip = str(input("Enter Server IP: "))
dst_ip = "10.0.1.2"

s = socket.socket()
print ("Socket successfully created")

dport = 12346

s.bind((dst_ip, dport))
print ("socket binded to %s" %(dport))

s.listen(5)
print ("socket is listening")

my_table = {}


while True:
  c, addr = s.accept()
  print ('Got connection from', addr )
  recvmsg = c.recv(1024).decode()
  print('Server received '+recvmsg)
  
  data_parse = recvmsg.split(" ")

  if(len(data_parse) != 3 or data_parse[2] != "HTTP/1.1\r\n\r\n"):
    c.send('HTTP/1.1 400 bad request\r\n\r\n'.encode())
    continue

  if(data_parse[0] == "PUT"):
    #PUT /assignment1/key1/val1 HTTP/1.1

    data_parse_1 = data_parse[1].split("/")

    if(len(data_parse_1) != 4 or data_parse_1[0] != "" or data_parse_1[1] != "assignment1"):
      c.send('HTTP/1.1 400 bad request\r\n\r\n'.encode())
      continue
    

    key = data_parse_1[2]
    val = data_parse_1[3]
    

    my_table[key] = val
    c.send('HTTP/1.1 201 OK\r\n\r\n'.encode())

  

  elif(data_parse[0] == "GET"):
    #GET /assignment1?request=key1 HTTP/1.1

    data_parse_1 = data_parse[1].split("?")

    if(len(data_parse_1) != 2):
      c.send('HTTP/1.1 400 bad request\r\n\r\n'.encode())
      continue
    

    data_parse_1_1 = data_parse_1[1].split("=")

    if(data_parse_1[0] != "/assignment1" or data_parse_1_1[0] != "request"):
      c.send('HTTP/1.1 400 bad request\r\n\r\n'.encode())
      continue
    

    key = data_parse_1_1[1]
    if key in my_table.keys():
      val = my_table[key]
      c.send('HTTP/1.1 200 OK\nValue = '+ val +' \r\n\r\n'.encode())
    else:
      c.send('HTTP/1.1 404 not found\r\n\r\n'.encode())

    

    
  

  elif(data_parse[0] == "DELETE"):
    #DELETE /assignment1/key1 HTTP/1.1

    data_parse_1 = data_parse[1].split("/")


    if(len(data_parse_1) != 3 or data_parse_1[0] != "" or data_parse_1[1] != "assignment1"):
      c.send('HTTP/1.1 400 bad request\r\n\r\n'.encode())
      continue

    key = data_parse_1[2]
    if key in my_table.keys():
       del my_table[key]
       c.send('HTTP/1.1 200 OK\nKey = '+ key +' deleted successfully\r\n\r\n'.encode())
    else:
       c.send('HTTP/1.1 404 not found\r\n\r\n'.encode())

  else:
    c.send('HTTP/1.1 400 bad request\r\n\r\n'.encode())

  

  #Write your code here
  #1. Uncomment c.send 
  #2. Parse the received HTTP request
  #3. Do the necessary operation depending upon whether it is GET, PUT or DELETE
  #4. Send response
  ##################

  c.close()
  #break