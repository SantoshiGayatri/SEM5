import socket

cacheIP = "10.0.1.2"

# dst_ip = str(input("Enter dstIP: "))
dst_ip = "10.0.1.2"

print(dst_ip)

port = 12346

while(True):
	Type_Request = str(input('Enter type of request : '))
	if(Type_Request == "exit"): 
		break

	s = socket.socket()
	s.connect((dst_ip, port))

	if(Type_Request == "1"):
		Key = str(input('Enter the Key : '))
		Val = str(input('Enter the Value : '))
		s.send('PUT /assignment1/'+Key+ '/' +Val+ ' HTTP/1.1\r\n\r\n'.encode())
		print ('Client received '+s.recv(1024).decode())

	elif(Type_Request == "2"):
		Key = str(input('Enter the Key : '))
		s.send('GET /assignment1?request=' +Key+  ' HTTP/1.1\r\n\r\n'.encode())
		print ('Client received '+s.recv(1024).decode())

	else:
		print('Enter Valid type of request ')
		print('Enter "exit" to end the process')
		print('Enter "1" for PUT request')
		print('Enter "2" for GET request')
		
	
	s.close()