import socket


serverIP = "10.0.1.3"


# dst_ip1 = str(input("Enter Server IP: "))
# dst_ip2 = str(input("Enter Cache  IP: "))
dst_ip1 = "10.0.1.3"
dst_ip2 = "10.0.1.2"


s2 = socket.socket()

print ("Sockets successfully created")

dport1 = 12356

dport2 = 12346

s2.bind((dst_ip2, dport2))


print ("socket 2 binded to %s" %(dport2))



s2.listen(5)
print ("socket 2  is listening")


my_table = {}


while True:
  c, addr = s2.accept()
  print ('Got connection from', addr )
  recvmsg = c.recv(1024).decode()
  print('Cache received '+recvmsg)
  
  data_parse = recvmsg.split(" ")

  if(len(data_parse) != 3 or data_parse[2] != "HTTP/1.1\r\n\r\n"):
    c.send('HTTP/1.1 400 bad request\r\n\r\n'.encode())
    continue

  if(data_parse[0] == "PUT"):
    #PUT /assignment1/key1/val1 HTTP/1.1

    data_parse_1 = data_parse[1].split("/")

    if(len(data_parse_1) != 4 or data_parse_1[0] != "" or data_parse_1[1] != "assignment1"):
      c.send('HTTP/1.1 400 bad request\r\n\r\n'.encode())
      continue
    

    key = data_parse_1[2]
    val = data_parse_1[3]

    if key in my_table.keys():
      my_table[key] = val
    
    s1 = socket.socket()
    s1.connect((dst_ip1, dport1))
    s1.send(recvmsg.encode())
    c.send((s1.recv(1024).decode()).encode())
    s1.close()

  

  elif(data_parse[0] == "GET"):
    #GET /assignment1?request=key1 HTTP/1.1

    data_parse_1 = data_parse[1].split("?")

    if(len(data_parse_1) != 2):
      c.send('HTTP/1.1 400 bad request\r\n\r\n'.encode())
      continue
    

    data_parse_1_1 = data_parse_1[1].split("=")

    if(data_parse_1[0] != "/assignment1" or data_parse_1_1[0] != "request"):
      c.send('HTTP/1.1 400 bad request\r\n\r\n'.encode())
      continue
    

    key = data_parse_1_1[1]
    if key in my_table.keys():
      val = my_table[key]
      c.send('HTTP/1.1 200 OK\nValue = '+ val +' \r\n\r\n'.encode())
      print("ALREADY PRESENT in CACHE")
    else:
      s1 = socket.socket()
      s1.connect((dst_ip1, dport1))
      s1.send(recvmsg.encode())
      recvmsg = s1.recv(1024).decode()
      parse_recv_msg = recvmsg.split(" ")
      
      if(parse_recv_msg[1] == "200"):
        print("UPDATED into CACHE")
        val = parse_recv_msg[4]
        my_table[key] = val
      

      c.send(recvmsg.encode())
      s1.close()
      

  else:
    c.send('HTTP/1.1 400 bad request\r\n\r\n'.encode())

  c.close()
  #break