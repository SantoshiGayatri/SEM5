#!/bin/bash

# Run simplerecv.py in a new terminal
gnome-terminal --tab --title="Receiver" -- bash -c "python3 receiver.py 9000; exec bash"

# Run directory_authority.py in a new terminal
gnome-terminal --tab --title="Directory Authority" -- bash -c "python3 dir_auth.py 8000; exec bash"

# Run node.py in a new terminal
gnome-terminal --tab --title="Node 1" -- bash -c "python3 node.py 7788 127.0.0.1 8000; exec bash"

# Run node.py in a new terminal
gnome-terminal --tab --title="Node 2" -- bash -c "python3 node.py 7447 127.0.0.1 8000; exec bash"

# Run another instance of node.py in a new terminal
gnome-terminal --tab --title="Exit 1" -- bash -c "python3 node.py 8010 127.0.0.1 8000 --exit; exec bash"

# Run client.py in a new terminal
gnome-terminal --tab --title="Client" -- bash -c "python3 client.py 127.0.0.1 8000 127.0.0.1 9000; exec bash"