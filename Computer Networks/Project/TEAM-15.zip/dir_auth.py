from Crypto.PublicKey import RSA
from Crypto.Cipher import AES, PKCS1_OAEP
import socket
import argparse
import random
import custom
from termcolor import colored

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("dir_auth_port", help="the port number of the directory authority")
    args = parser.parse_args()

    RSA_KEY_SIZE = 212
    NUM_NODES = 2

    relay_nodes = {}
    exit_nodes = {}
    
    #get the DA private key from a file
    da_file = open('private_key.pem','r')
    da_private = da_file.read()
    da_mykey = RSA.importKey(da_private)
    # da_file.close()

    da_IP, da_port = "127.0.0.1", args.dir_auth_port

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((da_IP, int(da_port)))
    s.listen(1)
    # print("Here1 dir_auth_py")

    while True:
        (clientsocket, addr) = s.accept()
        print("Here2 dir_auth_py", addr)

        request_type = clientsocket.recv(1)
        if request_type == b'':
            print("Closing 8")
            clientsocket.close()
            continue

        if request_type == b'n': #relay node
            print("Here3 n dir_auth_py")
            msg = custom.recvn(clientsocket,RSA_KEY_SIZE+8)
            if msg ==b'':
                print("Closing 9")
                clientsocket.close()
                continue
            node_addr = msg[:8]
            key = msg[8:]
            relay_nodes[node_addr] = key
            print(custom.unpackHostPort(node_addr)[1], "dir_aut")
            print((colored("DA["+da_port+"]: registered a relay node on port " + str(custom.unpackHostPort(node_addr)[1]), 'green')))
        
        elif request_type == b'e': #exit node
            print("Here4 e dir_auth_py")
            msg = custom.recvn(clientsocket,RSA_KEY_SIZE+8)
            if msg == b'':
                print("Closing 10")
                clientsocket.close()
                continue
            node_addr = msg[:8]
            key = msg[8:]
            exit_nodes[node_addr] = key
            print(custom.unpackHostPort(node_addr)[1], "dir_aut")
            print((colored("DA["+da_port+"]: registered an exit node on port " + str(custom.unpackHostPort(node_addr)[1]), 'green')))
        
        elif request_type == b"r": #route
            # print("Here5")
            #recieve encrypted aes key from client
            aes_enc = custom.recvm(clientsocket)
            if aes_enc == b'':
                print("Closing 11")
                clientsocket.close()
                continue

            # Use PKCS1_OAEP for decryption
            cipher = PKCS1_OAEP.new(da_mykey)
            aes_key = cipher.decrypt(aes_enc)

            relay_list = random.sample(list(relay_nodes.items()), NUM_NODES - 1)
            exit = random.sample(list(exit_nodes.items()), 1)
            if exit_nodes:  # Check if exit_nodes is not empty
                exit = random.sample(list(exit_nodes.items()), 1)
            else: # empty case
                print("Error: No exit nodes available.")
                exit = None  # or any other appropriate action
            # print(relay_nodes)
            # print(exit_nodes)
            route_msg = construct_route(relay_list, exit)
            # print("relay_list", relay_list)

            aes_obj = AES.new(aes_key, AES.MODE_CBC, b"0" * 16)
            blob = aes_obj.encrypt(custom.pad_msg(str(route_msg)))
            custom.sendm(clientsocket, blob)
            print((colored("DA[" + da_port + "]: sent a route to a client", 'green')))


def construct_route(relays,exit):
    msg = b''
    for a,b in relays:  msg += a+b
        # print(a, b)
    msg += exit[0][0]+exit[0][1]
    return msg


if __name__ == "__main__":
    main()
