import socket
import sys
import signal
from termcolor import colored

import custom

def main():
    signal.signal(signal.SIGINT, custom.signal_handler)
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    s.bind(('127.0.0.1', int(sys.argv[1])))
    s.listen(1)
    
    print((colored("Awaiting a connection...", "red")))
    # print("Her11")
    (clientsocket, addr) = s.accept()
    print("Receiver is listening to ", addr)
    print((colored("\n\nAccepted a connection!", "red")))

    try:
        while True:
            msg = custom.recvm(clientsocket)
            if msg == b'': break

            print((colored("Anonymous message: ", 'yellow')))
            print((colored(msg.decode(), 'yellow')))
            print((colored("Please type a response.", "red")))
            revmsg = input()

            if revmsg == "QUIT": break

            bytessent = custom.sendm(clientsocket, revmsg)

            if bytessent == 0: break

    except Exception as e: print(("Error: {}".format(e)))

    finally:
        print("Closing here 30")
        clientsocket.close()
        print("Closing here 31")
        s.close()

    print("\n\nLost connection to client. Closing...\n")


if __name__ == "__main__":
    main()