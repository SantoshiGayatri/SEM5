import struct
from Crypto.Random import get_random_bytes
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP, AES
import socket
import custom
import sys
import signal
import os
from termcolor import colored

def recvm(fro):
    packedlen = recvn(fro, 4)
    if packedlen == b"":
        return b""
    length = struct.unpack("!I", packedlen)[0]

    # Receive the actual msg using the calculated length
    msg = recvn(fro, length)
    # print(msg)
    return msg

def sendm(to, msg):
    prefix = struct.pack("!I", len(msg))
    
    bytessent = sendn(to, prefix)
        
    if bytessent == 0:
        return False
    
    bytessent = sendn(to, msg)
    if bytessent == 0:
        return False
    return True

def add_layer(msg, aes_key):
    iv = get_random_bytes(16)
    aes_obj = AES.new(aes_key, AES.MODE_CBC, iv)
    ciphertext = aes_obj.encrypt(custom.pad_msg(str(msg)))
    return iv + ciphertext

def peel_layer(ciphertext, aes_key):
    iv = ciphertext[:16]
    ciphertext = ciphertext[16:]
    aes_obj = AES.new(aes_key, AES.MODE_CBC, iv)
    msg = aes_obj.decrypt(ciphertext)
    return msg

def unpad_msg(msg):
    return msg[:-ord(msg[-1])]

def wrap_msg(msg, rsa_key, aes_key):
    aes_obj = AES.new(aes_key, AES.MODE_CBC, ("0" * 16).encode())
    ciphertext_aes = aes_obj.encrypt(msg)
    a = RSA.import_key(rsa_key)
    cipher_rsa = PKCS1_OAEP.new(a)
    ciphertext_rsa = cipher_rsa.encrypt(aes_key)
    blob = ciphertext_rsa + ciphertext_aes
    return blob

def unwrap_msg(blob, rsa_key):
    # Split the blob into ciphertext_rsa and ciphertext_aes
    ciphertext_rsa = blob[:128]
    ciphertext_aes = blob[128:]

    # Decrypt the AES key using RSA
    # a = RSA.import_key(rsa_key)
    cipher_rsa = PKCS1_OAEP.new(rsa_key)
    aes_key = cipher_rsa.decrypt(ciphertext_rsa)

    # Decrypt the msg using the obtained AES key
    aes_obj = AES.new(aes_key, AES.MODE_CBC, ("0" * 16).encode())
    decrypted_msg = aes_obj.decrypt(ciphertext_aes)

    return decrypted_msg

def is_socket_open(sock):
    try:
        # Attempt a non-disruptive operation on the socket
        sock.getpeername()
        return True
    except (socket.error, BrokenPipeError):
        return False

def sendn(to, msg):
    length = len(msg)
    sent_so_far = 0
    while length > sent_so_far:

        # print(length, is_socket_open(to))
        bytessent = to.send(msg[sent_so_far:])
        # to.listen(5)
        # print(length, is_socket_open(to), bytessent)
        if bytessent == 0:
            return 0
        sent_so_far += bytessent
    return length

def recvn(fro, length):
    recv_so_far = 0
    recvbuf = b''
    # print(is_socket_open(fro), "1")
    while length > recv_so_far:
        # print(is_socket_open(fro), "2")
        newdata = fro.recv(length - recv_so_far)
        # print(is_socket_open(fro), "3")
        bytesrecvd = len(newdata)
        if bytesrecvd == 0:
            return b''
        recvbuf += newdata
        recv_so_far += bytesrecvd

    if len(recvbuf) != length:
        return b''
    return recvbuf

def pad_msg(msg):
    """
    Pads a string for use with AES encryption
    :param msg: string to be padded
    :return: padded msg
    """
    pad_size = 16 - (len(msg) % 16)
    if pad_size == 0:
        pad_size = 16
    msg += chr(pad_size) * pad_size
    return msg.encode()

def recvn_with_retry(fro, n, max_retries=10):
    for _ in range(max_retries):
        try:
            data = b""
            while len(data) < n:
                chunk = fro.recv(n - len(data))
                if not chunk:
                    raise ConnectionResetError("Connection reset by peer")
                data += chunk
            return data  # Return if successful
        except ConnectionResetError as cre:
            print(f"Connection reset error: {cre}")
    print("Failed to receive data after max retries.")
    return b""  # or raise an exception, depending on your requirements

def packHostPort(ip, port):
    return socket.inet_aton(ip) + struct.pack("!i", port)

def unpackHostPort(packed):
    ip_address = socket.inet_ntoa(packed[:4])
    port = struct.unpack("!i", packed[4:])[0]  # Unpack 2 bytes for port
    print(ip_address, port, "--> utils.py")
    return (ip_address, port)

def unpackHostPort2(packed):
    ip_address = socket.inet_ntoa(packed[:4])
    port = struct.unpack("!i", packed[4:6])[0]  # Unpack 2 bytes for port
    print(ip_address, port, "--> utils.py")
    return (ip_address, port)

def packRoute(hoplist):
    msg = b""
    for i in range(0, len(hoplist)):
        idx = len(hoplist) - 1 - i
        msg = hoplist[idx][0] + msg
        msg = wrap_msg(msg, hoplist[idx][1])
    return msg

def wrap_all_msgs(hoplist, dest):
    def wrapper(msg, rsa_key, aes_key):
        aes_obj = AES.new(aes_key, AES.MODE_CBC, ("0" * 16).encode())
        ciphertext_aes = aes_obj.encrypt(msg)
        a = RSA.import_key(rsa_key)
        cipher_rsa = PKCS1_OAEP.new(a)
        ciphertext_rsa = cipher_rsa.encrypt(aes_key)
        blob = ciphertext_rsa + ciphertext_aes
        return blob

    wrapped_msg = dest
    aes_key_list = []
    packedroute = b""
    for i in range(0, len(hoplist)):
        elem_key = get_random_bytes(32)
        aes_key_list.append(elem_key)
        if i != 0:
            packedroute = packHostPort(hoplist[i - 1][0], hoplist[i - 1][1])
        wrapped_msg = packedroute + wrapped_msg
        print(hoplist[i][2], "HOPLIST")
        wrapped_msg = wrapper(pad_msg(str(wrapped_msg)), hoplist[i][2], elem_key)
    return wrapped_msg, aes_key_list

def add_all_layers(aes_key_list, msg):
    msg = pad_msg(str(msg))
    for key in aes_key_list:
        msg = add_layer(msg, key)
    return msg

def peel_all_layers(aes_key_list, res):
    
    def peeler(cipher, aes_key):
        iv = cipher[:16]
        cipher = cipher[16:]
        aes_obj = AES.new(aes_key, AES.MODE_CBC, iv)
        msg = aes_obj.decrypt(cipher)
        return msg
    
    for i in reversed(list(range(0, len(aes_key_list)))):
        res = peeler(res, aes_key_list[i])
    res = unpad_msg(res)
    return res

def validate_port(port):
    return 0 <= port <= 65535


def process_route(data):
    hoplist = []
    while len(hoplist) < 2:
        if len(data) < 220:  # Ensure there's enough data for another hop
            print("Warning: Not enough data to process another hop.")
            break

        hostport = unpackHostPort(data[:8])
        rsa_key = data[8:220]

        if validate_port(hostport[1]):
            hoplist.append((hostport[0], hostport[1], rsa_key))
        else:
            print(f"Warning: Port number {hostport[1]} is out of range. Skipping this hop.")

        data = data[220:]

    return hoplist

def signal_handler(received_signal, frame):
    os.killpg(os.getpgid(0), signal.SIGINT)
    sys.exit(0)
