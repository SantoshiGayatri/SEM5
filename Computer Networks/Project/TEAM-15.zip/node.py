from Crypto.PublicKey import RSA
import socket
from signatures import *
import custom
import sys
import threading
import argparse
import os
from termcolor import colored

portstring = ""
proxy = False

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--exit", help="run as an exit node", action="store_true")
    parser.add_argument("--dbg", help="use public.pem and private.pem", action="store_true")
    parser.add_argument("--proxy", help="run as http proxy node", action="store_true")
    parser.add_argument("portno", type=int, help="the port this node should listen on")
    parser.add_argument("dir_auth_ip", help="the ip address of the directory authority")
    parser.add_argument("dir_auth_port", type=int, help="the port number of the directory authority")
    args = parser.parse_args()
    global proxy
    proxy = args.proxy
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('127.0.0.1', args.portno))
    global portstring
    portstring = str(args.portno)
    # print('args.portno ' + portstring) # TBR
    # print('args.dbg ' + str(args.dbg)) # TBR
    s.listen(1)

    # Generate RSA keys, register self with directory authority
    mykey = RSA.generate(1024)
    if args.dbg:
        # print("Here1")
        f = open('private.pem', 'rb')
        private = f.read()
        print("node.py private ",private)
        f.close()
        mykey = RSA.importKey(private)
        print("node.py mykey ", mykey)
    else:
        dir_auth = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:  dir_auth.connect((args.dir_auth_ip, args.dir_auth_port))
        except socket.error as e: print("Error Connecting to the directory Authority port")
            
        result = 0
        # send an 'e' for exit node here, 'n' for relay node
        if args.exit:
            result = dir_auth.send(b'e')
            print("Here in node exit", result)
        else:
            result = dir_auth.send(b'n')
            print("Here in node relay", result)

        if result == 0:
            print((colored("N[" + portstring + "]: The directory authority went offline during registration! Terminating relay process...", 'cyan')))
            sys.exit(1)
        msg = custom.packHostPort('127.0.0.1',args.portno) + mykey.exportKey(format = "OpenSSH", passphrase=None, pkcs = 1)
        print("msg sent to dir auth port", msg)
        result = custom.sendn(dir_auth, msg)
        if result == 0:  print((colored("N[" + portstring + "]: The directory authority went offline during registration! Terminating relay process...", 'cyan')))
        
    while True:
        clientsocket, addr = s.accept()
        print(str(addr), "Adress of client socket at this node")
        threading.Thread(target=startSession, args=(clientsocket, mykey, args.exit)).start()
        print((colored("N[" + portstring + "]: New session started", 'cyan')))

def startSession(prevhop, mykey, is_exit):
    try:
        routemsg = custom.recvm(prevhop)
        print("prevhop", prevhop)
        # print(routemsg)
    except OSError as e: routemsg = b''
    if routemsg == b'':
        #kill this thread
        print("returning")
        return
    try:
        aeskey, hostport, nextmsg = peelRoute(routemsg, mykey)
        print("Peeled")
    except ValueError:
        print("Can't Peel")
        prevhop.shutdown(socket.SHUT_RDWR)
        return
    
    nexthost, nextport = custom.unpackHostPort(hostport)
    nexthop = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    nexthop.connect((nexthost, nextport))
    
    if nextmsg != b'':  custom.sendm(nexthop, nextmsg)
    
    fwd = threading.Thread(target=fwd, args=(prevhop, nexthop, aeskey, is_exit))
    bwd = threading.Thread(target=bkwd, args=(prevhop, nexthop, aeskey, is_exit))
    fwd.start()
    bwd.start()
    fwd.join()
    bwd.join()
    return

def fwd(prevhop, nexthop, aeskey, is_exit):
    while True:
        try:  msg = custom.recvm(prevhop)
        except OSError as e: msg = b''
        if msg == b'':
            #closing sockets interfere with other threads that use them
            try:
                prevhop.shutdown(socket.SHUT_RDWR)
                nexthop.shutdown(socket.SHUT_RDWR)
            except OSError as e: pass
            return
        msg = custom.peel_layer(msg, aeskey)
        if is_exit:  msg = custom.unpad_msg(msg)
        bytessent = 0
        try:
            if (is_exit and proxy): bytessent = nexthop.send(msg)
            else: bytessent = custom.sendm(nexthop, msg)
            print((colored("N[" + portstring + "]: Hopped forwards", 'cyan')))
        except OSError as e:
            pass
        if bytessent == 0:
            print((colored("N[" + portstring + "]: process " + str(os.getpid()) + " closing fwd", 'cyan')))
            try:
                prevhop.shutdown(socket.SHUT_RDWR)
                nexthop.shutdown(socket.SHUT_RDWR)
            except OSError as e:
                pass
            return

def bkwd(prevhop, nexthop, aeskey, is_exit):
    while True:
        msg = b''
        if (is_exit and proxy):
            while True:
                data = nexthop.recv(1024)
                if len(data) > 0:
                    msg += data
                else:
                    break
        else:
            try:
                msg = custom.recvm(nexthop)
            except OSError as e:
                msg = b''
        if msg == b'':
            #closing sockets may screw with other threads that use them
            try:
                prevhop.shutdown(socket.SHUT_RDWR)
                nexthop.shutdown(socket.SHUT_RDWR)
            except OSError as e:
                pass
            return
        if is_exit:
            msg = custom.add_layer(custom.pad_msg(str(msg)), aeskey)
        else:
            msg = custom.add_layer(msg, aeskey)
        bytessent = 0
        try:
            bytessent = custom.sendm(prevhop, msg)
            print((colored("N[" + portstring + "]: Hopped backwards", 'cyan')))
        except OSError as e:
            pass
        if bytessent == 0:
            try:
                prevhop.shutdown(socket.SHUT_RDWR)
                nexthop.shutdown(socket.SHUT_RDWR)
            except OSError as e:
                pass
            return

def peelRoute(msg, mykey):
    # print("-----------------------")
    # print(msg)
    # print("-----------------------")
    msg, aeskey = custom.unwrap_msg(msg, mykey)
    msg = custom.unpad_msg(msg)
    host, port = custom.unpackHostPort(msg[:8])
    hostport = msg[:8]
    nextmsg = msg[8:] #if nextmsg is an empty string, I'm an exit node
    return (aeskey, hostport, nextmsg)


if __name__ == "__main__":
    main()
