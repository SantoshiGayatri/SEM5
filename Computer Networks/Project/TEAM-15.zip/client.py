from Crypto.PublicKey import RSA
from Crypto.Cipher import AES
from Crypto import Random
import socket
import argparse
import custom
from termcolor import colored
from Crypto.Cipher import PKCS1_OAEP

ROUTE_REQUEST_TYPE = b'r'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("dir_auth_ip", help="the ip address of the directory authority")
    parser.add_argument("dir_auth_port", help="the port number of the directory authority")
    parser.add_argument("destination_ip", help="the ip address of the destination")
    parser.add_argument("destination_port", help="the port number of the destination")
    args = parser.parse_args()
    # print("Parsed Args")
    DA_IP, DA_PORT = args.dir_auth_ip, args.dir_auth_port
    DEST_HOST, DEST_PORT = args.destination_ip, args.destination_port

    da_file = open('public_key.pem', 'rb')
    da_pub_key = da_file.read()
    da_pub_key = RSA.importKey(da_pub_key)
    
    da_file1 = open('private_key.pem', 'rb')
    da_priv_key = da_file1.read()
    da_priv_key = RSA.importKey(da_priv_key)

    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((DA_IP, int(DA_PORT)))
        s.send(ROUTE_REQUEST_TYPE) 
        # print("Success")
    except socket.error as e:
        print(f"Socket Error: {e}")
        print("Closing 1")
        # print("Not Success")
        s.close()
        quit()

    randfile = Random.new()
    aes_key = randfile.read(32)
    aes_obj = AES.new(aes_key, AES.MODE_CBC, b"0" * 16)

    cipher = PKCS1_OAEP.new(da_pub_key)
    # cipher = AES.new(aes_key, AES.MODE_CBC)
    print("Here -- client1")
    aes_msg = cipher.encrypt(aes_key)
    succ = custom.sendm(s, aes_msg)
    
    if not succ:
        print("Directory authority connection failed!!!!")
        print("Closing 2")
        s.close()
        quit()
    # print(succ)
    print("Here -- client2")
# Receive data
    data = custom.recvm(s)  # All info from directory authority
    if data == b'':
        print("Closing 3")
        s.close()
        print("Directory authority connection failed")
        quit()

    print("Here -- client3")
    hop_data = aes_obj.decrypt(data)
    # print("data", data)
    # print("hop_data", hop_data)
    hoplist = custom.process_route(hop_data)
    hoplist = list(reversed(hoplist))
        
    # print(hoplist)
    # if 0 <= int(DEST_PORT) <= 65535:
    #     client_wrapper(hoplist, utils.packHostPort(DEST_HOST, int(DEST_PORT)))
    # else:
    #     print("Error: Invalid port number. Port must be in the range 0-65535.")
    
    print("Here I am !!!!!!!")
    client_wrapper(hoplist, custom.packHostPort(DEST_HOST, int(DEST_PORT)))
    
def client_wrapper(hoplist, destination):
    
    print(f"Length of hoplist: {len(hoplist)}")
    last_hop = hoplist[len(hoplist)-1]
    print(f"Original port in hoplist: {last_hop[1]}")

    next_host = (last_hop[0], last_hop[1])

    next_s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    next_s.connect(next_host)
    print("After connection!")
    
    # Generate wrapped msg
    wrapped_msg, aes_key_list = custom.wrap_all_msgs(hoplist, destination)

    custom.sendm(next_s, wrapped_msg)

    while True:
        print( colored("CLIENT: Enter the message to server here!", 'yellow'))
        msg = input()
        msg = custom.add_all_layers(aes_key_list, msg)
        try:  custom.sendm(next_s, msg)
        except socket.error as e:  return
        
        try:  response = custom.recvm(next_s)
        except socket.error as e: return
        
        response = custom.peel_all_layers(aes_key_list, response)
        
        print(colored("CLIENT: server responsed with:", 'red'))
        print(colored(response, 'red'))

if __name__ == "__main__":
    main()